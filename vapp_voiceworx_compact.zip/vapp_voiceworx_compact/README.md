# Voiceworx V‑App (compact)
Render: Docker runtime, add SECRET_KEY env var, add Disk /app/uploads.
